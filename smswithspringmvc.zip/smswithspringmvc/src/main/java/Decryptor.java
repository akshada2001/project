import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

public class Decryptor {
    private static final String AES_KEY = "YourSecretKey"; // Replace with your actual key

    public static void main(String[] args) {
        String originalString = "YourOriginalString"; // Replace with your actual original string
        String encryptedString = encrypt(originalString, AES_KEY);
        String decryptedString = decrypt(encryptedString, AES_KEY);
        
        // Check if encrypted string is equal to decrypted string
        boolean isEqual = originalString.equals(decryptedString);
        
        System.out.println("Original string: " + originalString);
        System.out.println("Encrypted string: " + encryptedString);
        System.out.println("Decrypted string: " + decryptedString);
        System.out.println("Is decrypted string equal to original string? " + isEqual);
    }

    public static String encrypt(String originalString, String key) {
        try {
            byte[] decodedKey = Base64.getDecoder().decode(key);
            SecretKeySpec secretKeySpec = new SecretKeySpec(decodedKey, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
            byte[] encryptedBytes = cipher.doFinal(originalString.getBytes());
            return Base64.getEncoder().encodeToString(encryptedBytes);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String decrypt(String encryptedString, String key) {
        try {
            byte[] decodedKey = Base64.getDecoder().decode(key);
            SecretKeySpec secretKeySpec = new SecretKeySpec(decodedKey, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
            byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedString));
            return new String(decryptedBytes);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
