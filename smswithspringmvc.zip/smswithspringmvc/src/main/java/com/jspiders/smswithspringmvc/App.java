package com.jspiders.smswithspringmvc;

public class App {

}
