package com.jspiders.smswithspringmvc.pojo;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Test {
	
public static void main(String[] args) {
		
		
		
		long currentTimeMillis = System.currentTimeMillis();
		String originalPassword = "Admin@123";
		String storedHashPassword = "$2a$12$DciuNznR0cCkLZq5JrI0vumhuhsN5Cw7M261yCNaXLOZoYLqMpyh6";
		
		boolean isEquals = originalPassword.equals(storedHashPassword);
		if(isEquals) {
			System.out.println("Matches");
		}else {
			System.out.println("Not Matches");
		}
		
		System.out.println("Time taken for credential validation with password encoder, {}"+ (System.currentTimeMillis() - currentTimeMillis));
		
		
		
	    }

	
    
    
	public static String decrypt(String encryptedString, String key) {
        try {
            byte[] decodedKey = Base64.getDecoder().decode(key);
            SecretKeySpec secretKeySpec = new SecretKeySpec(decodedKey, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
            byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedString));
            return new String(decryptedBytes);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


}
