package com.jspiders.smswithspringmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jspiders.smswithspringmvc.pojo.AdminPojo;
import com.jspiders.smswithspringmvc.repository.AdminRepository;

@Component
public class AdminService {

	@Autowired
	private AdminRepository adminRepository;

	public void addAdmin(String userName, String email, String password) {
		AdminPojo adminPOJO = new AdminPojo();
		adminPOJO.setUsername(userName);
		adminPOJO.setEmail(email);
		adminPOJO.setPassword(password);
		adminRepository.addAdmin(adminPOJO);
	}

	public AdminPojo logIn(String email, String password) {
		AdminPojo adminToBeLoggedIn = null;
		List<AdminPojo> admins = adminRepository.getAllAdmins();
		for (AdminPojo admin : admins) {
			if (admin.getEmail().equals(email) && admin.getPassword().equals(password)) {
				adminToBeLoggedIn = admin;
				break;
			}
		}
		return adminToBeLoggedIn;
	}

	public List<AdminPojo> getAllAdmins() {
		return adminRepository.getAllAdmins();
	}

	public void deleteAdmin(String email) {
		AdminPojo adminToBeDeleted = null;
		List<AdminPojo> admins = adminRepository.getAllAdmins();
		for (AdminPojo admin : admins) {
			if (admin.getEmail().equals(email)) {
				adminToBeDeleted = admin;
			}
		}
		adminRepository.deleteAdmin(adminToBeDeleted);
	}

}
